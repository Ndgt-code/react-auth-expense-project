import { useAuth } from "./context/AuthContext";
import ExpensePanel from "./components/ExpensePanel";

function App() {
  const { isLoggedIn, setIsLoggedIn } = useAuth();

  return (
    <div className="p-6 max-w-md mx-auto">
      <h1 className="text-2xl font-bold">Quản lý đăng nhập</h1>
      <button
        className="mt-4 px-4 py-2 bg-green-500 text-white rounded"
        onClick={() => setIsLoggedIn(!isLoggedIn)}
      >
        {isLoggedIn ? "Đăng xuất" : "Đăng nhập"}
      </button>
      <ExpensePanel />
    </div>
  );
}

export default App;
